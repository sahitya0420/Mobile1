package com.app.Appium.Emulator;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;

public class Mobiletest {
	
	AndroidDriver<MobileElement> driver;
	
	@Test()
	public void launch() throws MalformedURLException, InterruptedException
	{
	//to start the appium service using code
	//AppiumDriverLocalService service = AppiumDriverLocalService.buildDefaultService();
	//service.start();
	
	System.out.println("*****************************************************");
	System.out.println("Setting up device and desired capabilities");
	URL url= new URL("http://127.0.0.1:4723/wd/hub");
	
	//desired capabilities to open up the device
	DesiredCapabilities caps = DesiredCapabilities.android();	
	caps.setCapability("deviceName", "emulator-5554");
	caps.setCapability("udid", "emulator-5554"); //Give Device ID of your mobile phone
	caps.setCapability("platformName", "Android");
	caps.setCapability("platformVersion", "8.1.0");
	caps.setCapability("browserName", "Chrome");
	caps.setCapability("automationName", "UiAutomator2");
	caps.setCapability("noReset", true);
		
	//launching the android driver
	driver = new AndroidDriver<MobileElement>(url,caps);	
	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	driver.get("https://www.dbs.com.sg/personal/default.page");
	driver.findElement(By.id("btnHamburger")).click();
	driver.findElement(By.linkText("Cards")).click();
	Thread.sleep(2000);
	driver.findElement(By.linkText("Credit Cards")).click();
	
	//to scroll down in the page
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,700)");
	
	driver.findElement(By.xpath("//div[@data-category-details='Miles,All']//label[@class='compare-label']")).click();
	driver.findElement(By.xpath("//div[@data-category-details='Rebates,All']//label[@class='compare-label']")).click();
	driver.findElement(By.xpath("//button[@id='cardCompareBtn']")).click();
		
	js.executeScript("window.scrollBy(0,250)");
	 
	//validating after the comparision
	String text=driver.findElement(By.xpath("//div[@class='section-seperator']")).getText();
	Assert.assertTrue(text.contains("Best For"), "text is present");
	Assert.assertTrue(text.contains("It's the fastest way to fly anywhere."), "text is present");
	Assert.assertTrue(text.contains("Card Type"), "text is present");
	Assert.assertTrue(text.contains("VISA"), "text is present");
	Assert.assertTrue(text.contains("Min Income Per Annum"), "text is present");
	Assert.assertTrue(text.contains("S$30,000"), "text is present");
	Assert.assertTrue(text.contains("Min Income Per Annum Foreigners"), "text is present");
	Assert.assertTrue(text.contains("S$45,000"), "text is present");
	Assert.assertTrue(text.contains("Annual Fee Waiver"), "text is present");
	Assert.assertTrue(text.contains("1 Year"), "text is present");	
	}
}
